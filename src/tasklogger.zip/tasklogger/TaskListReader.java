package tasklogger;

public class TaskListReader {
	
}
